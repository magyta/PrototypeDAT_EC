"""
Dashboard — Control Metabólico DM2
Formularios 4, 5, 7 y 7.1 — Zona de Salud 3
Programa de Enfermedades Crónicas — MSP Ecuador

Uso:
    python dashboard_dm2.py
    Abrir navegador en http://127.0.0.1:8050
"""

import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from dash import Dash, dcc, html, Input, Output, dash_table
import os

# ══════════════════════════════════════════════════════════════════
# 1. CARGA DE DATOS
# ══════════════════════════════════════════════════════════════════
CSV_PATH = os.path.join(os.path.dirname(__file__), "datos_control_metabolico.csv")
df_raw = pd.read_csv(CSV_PATH, parse_dates=["fecha_captacion", "fecha_ult_control"])

# Convertir booleanos (CSV los guarda como strings)
bool_cols = ["hta", "dislipidemia", "obesidad", "prescripcion_educativa",
             "actividad_fisica_prescrita", "cambio_tratamiento",
             "hospitalizacion_periodo", "derivacion_especialidad",
             "ctrl_hba1c", "ctrl_presion_arterial", "ctrl_ldl", "triple_control_abc"]
for c in bool_cols:
    df_raw[c] = df_raw[c].astype(str).str.upper().map(
        {"TRUE": True, "FALSE": False, "1": True, "0": False}
    )

# ══════════════════════════════════════════════════════════════════
# 2. PALETA Y ESTILOS
# ══════════════════════════════════════════════════════════════════
C = {
    "azul":    "#2E5D9E",
    "teal":    "#0F6E56",
    "morado":  "#534AB7",
    "ambar":   "#C97A0B",
    "coral":   "#C2401F",
    "gris":    "#64748b",
    "fondo":   "#F8FAFC",
    "blanco":  "#FFFFFF",
    "borde":   "#E2E8F0",
    "texto":   "#1E293B",
    "verde":   "#16A34A",
    "rojo":    "#DC2626",
}

FONT = "Inter, Segoe UI, Arial, sans-serif"

card_style = {
    "background": C["blanco"],
    "borderRadius": "12px",
    "padding": "20px 24px",
    "border": f"1px solid {C['borde']}",
    "boxShadow": "0 1px 4px rgba(0,0,0,0.06)",
}

kpi_style = lambda color: {
    **card_style,
    "borderTop": f"4px solid {color}",
    "textAlign": "center",
    "minWidth": "160px",
    "flex": "1",
}

# ══════════════════════════════════════════════════════════════════
# 3. FUNCIONES AUXILIARES
# ══════════════════════════════════════════════════════════════════
def pct(series_bool):
    return round(series_bool.sum() / len(series_bool) * 100, 1)

def kpi_card(titulo, valor, unidad, color, delta=None):
    children = [
        html.P(titulo, style={"fontSize": "12px", "color": C["gris"],
                               "marginBottom": "6px", "fontWeight": "500",
                               "textTransform": "uppercase", "letterSpacing": ".04em"}),
        html.Div([
            html.Span(str(valor), style={"fontSize": "32px", "fontWeight": "700",
                                          "color": color, "lineHeight": "1"}),
            html.Span(f" {unidad}", style={"fontSize": "14px", "color": C["gris"],
                                            "marginLeft": "4px"}),
        ]),
    ]
    if delta is not None:
        sign = "▲" if delta >= 0 else "▼"
        c_d  = C["verde"] if delta >= 0 else C["rojo"]
        children.append(
            html.P(f"{sign} {abs(delta)} pp vs basal",
                   style={"fontSize": "11px", "color": c_d, "marginTop": "4px"})
        )
    return html.Div(children, style=kpi_style(color))


def figura_base():
    return dict(
        font_family=FONT,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=16, r=16, t=36, b=16),
    )


# ══════════════════════════════════════════════════════════════════
# 4. APP DASH
# ══════════════════════════════════════════════════════════════════
app = Dash(__name__, title="Dashboard DM2 — Zona Salud 3")

unidades_opciones = [{"label": "Todas las unidades", "value": "TODAS"}] + [
    {"label": u, "value": u} for u in sorted(df_raw["unidad_operativa"].unique())
]

app.layout = html.Div(style={"fontFamily": FONT, "background": C["fondo"],
                               "minHeight": "100vh", "padding": "0"}, children=[

    # ── ENCABEZADO ─────────────────────────────────────────────
    html.Div(style={
        "background": C["azul"], "color": C["blanco"],
        "padding": "20px 32px", "display": "flex",
        "justifyContent": "space-between", "alignItems": "center",
    }, children=[
        html.Div([
            html.H1("Dashboard — Control Metabólico DM2",
                    style={"margin": "0", "fontSize": "20px", "fontWeight": "700"}),
            html.P("Formularios 4 · 5 · 7 · 7.1 — Zona de Salud 3 · Programa de Enfermedades Crónicas",
                   style={"margin": "4px 0 0", "fontSize": "13px", "opacity": ".85"}),
        ]),
        html.Div([
            html.P("Unidad operativa", style={"fontSize": "12px", "marginBottom": "4px",
                                               "opacity": ".8"}),
            dcc.Dropdown(
                id="filtro-unidad",
                options=unidades_opciones,
                value="TODAS",
                clearable=False,
                style={"width": "240px", "fontSize": "13px", "color": C["texto"]},
            )
        ])
    ]),

    html.Div(style={"padding": "24px 32px"}, children=[

        # ── FILA KPIs ──────────────────────────────────────────
        html.Div(id="kpi-row", style={
            "display": "flex", "gap": "14px", "flexWrap": "wrap",
            "marginBottom": "24px"
        }),

        # ── FILA 1: Gauges + barra de evolución ───────────────
        html.Div(style={"display": "grid",
                         "gridTemplateColumns": "1fr 1fr",
                         "gap": "16px", "marginBottom": "16px"}, children=[
            html.Div([
                html.H3("Indicadores de control al 6.° mes",
                        style={"fontSize": "13px", "fontWeight": "600",
                               "color": C["texto"], "margin": "0 0 12px"}),
                dcc.Graph(id="gauges-control", style={"height": "260px"},
                          config={"displayModeBar": False})
            ], style=card_style),
            html.Div([
                html.H3("Reducción media de HbA1c por unidad operativa",
                        style={"fontSize": "13px", "fontWeight": "600",
                               "color": C["texto"], "margin": "0 0 12px"}),
                dcc.Graph(id="bar-reduccion-hba1c", style={"height": "260px"},
                          config={"displayModeBar": False})
            ], style=card_style),
        ]),

        # ── FILA 2: Distribución HbA1c + PA ───────────────────
        html.Div(style={"display": "grid",
                         "gridTemplateColumns": "1fr 1fr",
                         "gap": "16px", "marginBottom": "16px"}, children=[
            html.Div([
                html.H3("Distribución HbA1c — Basal vs 6.° mes (Form. 4 vs 7)",
                        style={"fontSize": "13px", "fontWeight": "600",
                               "color": C["texto"], "margin": "0 0 12px"}),
                dcc.Graph(id="hist-hba1c", style={"height": "260px"},
                          config={"displayModeBar": False})
            ], style=card_style),
            html.Div([
                html.H3("Presión arterial sistólica — Basal vs 6.° mes",
                        style={"fontSize": "13px", "fontWeight": "600",
                               "color": C["texto"], "margin": "0 0 12px"}),
                dcc.Graph(id="box-pas", style={"height": "260px"},
                          config={"displayModeBar": False})
            ], style=card_style),
        ]),

        # ── FILA 3: Dispersión + Prescripción educativa ────────
        html.Div(style={"display": "grid",
                         "gridTemplateColumns": "1.3fr 0.7fr",
                         "gap": "16px", "marginBottom": "16px"}, children=[
            html.Div([
                html.H3("HbA1c basal vs HbA1c 6m — Triple control ABC (Form. 4 vs 7)",
                        style={"fontSize": "13px", "fontWeight": "600",
                               "color": C["texto"], "margin": "0 0 12px"}),
                dcc.Graph(id="scatter-hba1c", style={"height": "300px"},
                          config={"displayModeBar": False})
            ], style=card_style),
            html.Div([
                html.H3("Prescripción educativa y AF (Form. 5)",
                        style={"fontSize": "13px", "fontWeight": "600",
                               "color": C["texto"], "margin": "0 0 12px"}),
                dcc.Graph(id="pie-educativa", style={"height": "300px"},
                          config={"displayModeBar": False})
            ], style=card_style),
        ]),

        # ── FILA 4: Adherencia + Tiempo dx-tratamiento ─────────
        html.Div(style={"display": "grid",
                         "gridTemplateColumns": "1fr 1fr",
                         "gap": "16px", "marginBottom": "16px"}, children=[
            html.Div([
                html.H3("Adherencia farmacológica y a consultas (Form. 7.1)",
                        style={"fontSize": "13px", "fontWeight": "600",
                               "color": C["texto"], "margin": "0 0 12px"}),
                dcc.Graph(id="bar-adherencia", style={"height": "240px"},
                          config={"displayModeBar": False})
            ], style=card_style),
            html.Div([
                html.H3("Tiempo diagnóstico → inicio de tratamiento (días)",
                        style={"fontSize": "13px", "fontWeight": "600",
                               "color": C["texto"], "margin": "0 0 12px"}),
                dcc.Graph(id="hist-tiempo-tto", style={"height": "240px"},
                          config={"displayModeBar": False})
            ], style=card_style),
        ]),

        # ── FILA 5: Tabla resumen por unidad ───────────────────
        html.Div([
            html.H3("Resumen de indicadores por unidad operativa",
                    style={"fontSize": "13px", "fontWeight": "600",
                           "color": C["texto"], "margin": "0 0 14px"}),
            html.Div(id="tabla-unidades")
        ], style=card_style),

        # ── PIE DE PÁGINA ──────────────────────────────────────
        html.P("Zona de Salud 3 · MSP Ecuador · Programa de Enfermedades Crónicas · Datos sintéticos de demostración",
               style={"textAlign": "center", "fontSize": "11px",
                      "color": C["gris"], "marginTop": "28px"}),
    ])
])


# ══════════════════════════════════════════════════════════════════
# 5. CALLBACKS
# ══════════════════════════════════════════════════════════════════
@app.callback(
    Output("kpi-row",               "children"),
    Output("gauges-control",        "figure"),
    Output("bar-reduccion-hba1c",   "figure"),
    Output("hist-hba1c",            "figure"),
    Output("box-pas",               "figure"),
    Output("scatter-hba1c",         "figure"),
    Output("pie-educativa",         "figure"),
    Output("bar-adherencia",        "figure"),
    Output("hist-tiempo-tto",       "figure"),
    Output("tabla-unidades",        "children"),
    Input("filtro-unidad", "value"),
)
def actualizar(unidad):
    df = df_raw if unidad == "TODAS" else df_raw[df_raw["unidad_operativa"] == unidad]

    # ── KPIs ──────────────────────────────────────────────────
    p_hba1c  = pct(df["ctrl_hba1c"])
    p_pa     = pct(df["ctrl_presion_arterial"])
    p_ldl    = pct(df["ctrl_ldl"])
    p_triple = pct(df["triple_control_abc"])
    p_educ   = pct(df["prescripcion_educativa"])
    red_mean = round(df["reduccion_hba1c"].mean(), 2)

    kpis = html.Div([
        kpi_card("HbA1c < 7%",        f"{p_hba1c}",  "%", C["azul"]),
        kpi_card("PA < 130/80",        f"{p_pa}",     "%", C["teal"]),
        kpi_card("LDL < 100 mg/dL",   f"{p_ldl}",    "%", C["morado"]),
        kpi_card("Triple control ABC", f"{p_triple}", "%", C["coral"]),
        kpi_card("Prescrip. educativa",f"{p_educ}",  "%", C["ambar"]),
        kpi_card("Reducción HbA1c",    f"{red_mean}", "pts", C["azul"]),
    ], style={"display": "flex", "gap": "14px", "flexWrap": "wrap"})

    fb = figura_base()

    # ── GAUGES ────────────────────────────────────────────────
    gauge_vals  = [p_hba1c, p_pa, p_ldl, p_triple]
    gauge_labs  = ["HbA1c<7%", "PA ctrl.", "LDL ctrl.", "Triple ABC"]
    gauge_cols  = [C["azul"], C["teal"], C["morado"], C["coral"]]
    gauge_metas = [50, 60, 40, 25]

    fig_gauges = go.Figure()
    for i, (val, lab, col, meta) in enumerate(zip(gauge_vals, gauge_labs, gauge_cols, gauge_metas)):
        fig_gauges.add_trace(go.Indicator(
            mode="gauge+number",
            value=val,
            title={"text": lab, "font": {"size": 11}},
            gauge={
                "axis": {"range": [0, 100], "tickfont": {"size": 9}},
                "bar":  {"color": col, "thickness": 0.6},
                "bgcolor": "#F1F5F9",
                "threshold": {"line": {"color": C["rojo"], "width": 2},
                              "thickness": 0.8, "value": meta},
            },
            domain={"row": 0, "column": i},
            number={"suffix": "%", "font": {"size": 18}},
        ))
    fig_gauges.update_layout(
        grid={"rows": 1, "columns": 4, "pattern": "independent"},
        **fb, margin=dict(l=8, r=8, t=28, b=8), height=220,
    )

    # ── BARRA REDUCCIÓN HbA1c POR UNIDAD ──────────────────────
    r_uo = (df.groupby("unidad_operativa")["reduccion_hba1c"]
              .mean().round(2).reset_index()
              .sort_values("reduccion_hba1c", ascending=True))
    fig_bar_red = go.Figure(go.Bar(
        y=r_uo["unidad_operativa"],
        x=r_uo["reduccion_hba1c"],
        orientation="h",
        marker_color=C["azul"],
        text=r_uo["reduccion_hba1c"].apply(lambda v: f"{v} pts"),
        textposition="outside",
    ))
    fig_bar_red.add_vline(x=1.0, line_dash="dash", line_color=C["rojo"],
                           annotation_text="Meta ≥ 1 pt", annotation_font_size=10)
    fig_bar_red.update_layout(**fb, height=240,
                               xaxis_title="Reducción media (puntos %)",
                               yaxis={"tickfont": {"size": 10}})

    # ── HISTOGRAMA HbA1c BASAL vs 6M ─────────────────────────
    fig_hist = go.Figure()
    fig_hist.add_trace(go.Histogram(
        x=df["hba1c_basal"], name="Basal (Form. 4)",
        marker_color=C["coral"], opacity=0.65,
        xbins=dict(start=5, end=15, size=0.5),
    ))
    fig_hist.add_trace(go.Histogram(
        x=df["hba1c_6m"], name="6.° mes (Form. 7)",
        marker_color=C["azul"], opacity=0.65,
        xbins=dict(start=5, end=15, size=0.5),
    ))
    fig_hist.add_vline(x=7.0, line_dash="dash", line_color=C["verde"],
                        annotation_text="Meta < 7%", annotation_font_size=10)
    fig_hist.update_layout(**fb, barmode="overlay", height=240,
                            xaxis_title="HbA1c (%)", yaxis_title="N° pacientes",
                            legend=dict(orientation="h", y=1.12, x=0))

    # ── BOX PAS ───────────────────────────────────────────────
    fig_box = go.Figure()
    fig_box.add_trace(go.Box(
        y=df["pas_basal"], name="Basal", marker_color=C["coral"],
        boxmean=True, line_width=1.5,
    ))
    fig_box.add_trace(go.Box(
        y=df["pas_6m"], name="6.° mes", marker_color=C["azul"],
        boxmean=True, line_width=1.5,
    ))
    fig_box.add_hline(y=130, line_dash="dash", line_color=C["verde"],
                       annotation_text="Meta < 130", annotation_font_size=10)
    fig_box.update_layout(**fb, height=240, yaxis_title="PAS (mmHg)",
                           legend=dict(orientation="h", y=1.1))

    # ── SCATTER HbA1c BASAL vs 6M ────────────────────────────
    df_s = df.copy()
    df_s["triple_label"] = df_s["triple_control_abc"].map(
        {True: "Con triple control", False: "Sin triple control"})
    fig_scatter = px.scatter(
        df_s, x="hba1c_basal", y="hba1c_6m",
        color="triple_label",
        color_discrete_map={"Con triple control": C["teal"], "Sin triple control": C["coral"]},
        hover_data=["id_paciente", "unidad_operativa", "reduccion_hba1c"],
        labels={"hba1c_basal": "HbA1c basal (%)", "hba1c_6m": "HbA1c 6.° mes (%)"},
        opacity=0.65, size_max=7,
    )
    fig_scatter.add_shape(type="line", x0=5, y0=5, x1=15, y1=15,
                           line=dict(dash="dot", color=C["gris"], width=1))
    fig_scatter.add_hline(y=7.0, line_dash="dash", line_color=C["verde"], line_width=1)
    fig_scatter.update_layout(**fb, height=280,
                               legend=dict(title="", orientation="h", y=1.08))

    # ── PIE PRESCRIPCIÓN EDUCATIVA / AF ───────────────────────
    educ_si  = df["prescripcion_educativa"].sum()
    educ_no  = len(df) - educ_si
    af_si    = df["actividad_fisica_prescrita"].sum()
    af_no    = len(df) - af_si
    fig_pie = go.Figure()
    fig_pie.add_trace(go.Pie(
        labels=["Con prescrip. educativa", "Sin prescrip. educativa"],
        values=[educ_si, educ_no],
        hole=0.55,
        marker_colors=[C["ambar"], "#E2E8F0"],
        textinfo="percent",
        domain={"x": [0, 0.48]},
        name="Educativa",
        title={"text": "Educ.", "font": {"size": 11}},
    ))
    fig_pie.add_trace(go.Pie(
        labels=["Con prescrip. AF", "Sin prescrip. AF"],
        values=[af_si, af_no],
        hole=0.55,
        marker_colors=[C["teal"], "#E2E8F0"],
        textinfo="percent",
        domain={"x": [0.52, 1.0]},
        name="Act. física",
        title={"text": "Act. Física", "font": {"size": 11}},
    ))
    fig_pie.update_layout(**fb, height=280,
                           legend=dict(orientation="h", y=-0.08, font={"size": 10}),
                           showlegend=False)

    # ── BARRA ADHERENCIA ──────────────────────────────────────
    ord_adh = ["Alta", "Media", "Baja"]
    adh_f   = df["adherencia_farmacologica"].value_counts().reindex(ord_adh, fill_value=0)
    adh_c   = df["adherencia_consultas"].value_counts().reindex(ord_adh, fill_value=0)
    col_adh = [C["teal"], C["ambar"], C["coral"]]
    fig_adh = go.Figure()
    for i, (cat, col) in enumerate(zip(ord_adh, col_adh)):
        fig_adh.add_trace(go.Bar(
            name=cat,
            x=["Farmacológica", "Consultas"],
            y=[adh_f[cat], adh_c[cat]],
            marker_color=col,
            text=[adh_f[cat], adh_c[cat]],
            textposition="outside",
        ))
    fig_adh.update_layout(**fb, barmode="group", height=220,
                           yaxis_title="N° pacientes",
                           legend=dict(orientation="h", y=1.12))

    # ── HISTOGRAMA TIEMPO DX → TRATAMIENTO ───────────────────
    fig_hist_tto = go.Figure(go.Histogram(
        x=df["dias_dx_a_tratamiento"],
        marker_color=C["morado"], opacity=0.8,
        xbins=dict(start=0, end=50, size=3),
    ))
    fig_hist_tto.add_vline(x=15, line_dash="dash", line_color=C["rojo"],
                            annotation_text="Meta ≤ 15 días", annotation_font_size=10)
    fig_hist_tto.update_layout(**fb, height=220,
                                xaxis_title="Días", yaxis_title="N° pacientes")

    # ── TABLA POR UNIDAD ──────────────────────────────────────
    resumen = df.groupby("unidad_operativa").agg(
        Pacientes           = ("id_paciente",        "count"),
        HbA1c_basal_media   = ("hba1c_basal",        lambda x: round(x.mean(),1)),
        HbA1c_6m_media      = ("hba1c_6m",           lambda x: round(x.mean(),1)),
        Reduccion_HbA1c     = ("reduccion_hba1c",    lambda x: round(x.mean(),2)),
        Ctrl_HbA1c_pct      = ("ctrl_hba1c",         lambda x: f"{round(x.mean()*100,1)}%"),
        Ctrl_PA_pct         = ("ctrl_presion_arterial", lambda x: f"{round(x.mean()*100,1)}%"),
        Ctrl_LDL_pct        = ("ctrl_ldl",           lambda x: f"{round(x.mean()*100,1)}%"),
        Triple_ABC_pct      = ("triple_control_abc", lambda x: f"{round(x.mean()*100,1)}%"),
        Educ_prescrita_pct  = ("prescripcion_educativa", lambda x: f"{round(x.mean()*100,1)}%"),
    ).reset_index().rename(columns={"unidad_operativa": "Unidad operativa"})

    tabla = dash_table.DataTable(
        data=resumen.to_dict("records"),
        columns=[{"name": c.replace("_", " "), "id": c} for c in resumen.columns],
        style_table={"overflowX": "auto"},
        style_header={
            "backgroundColor": C["azul"], "color": C["blanco"],
            "fontWeight": "600", "fontSize": "12px",
            "padding": "10px 12px", "border": "none",
        },
        style_cell={
            "fontSize": "12px", "padding": "8px 12px",
            "fontFamily": FONT, "color": C["texto"],
            "border": f"1px solid {C['borde']}",
        },
        style_data_conditional=[
            {"if": {"row_index": "odd"},
             "backgroundColor": "#F8FAFC"},
        ],
        sort_action="native",
        page_size=10,
    )

    return (kpis, fig_gauges, fig_bar_red, fig_hist,
            fig_box, fig_scatter, fig_pie, fig_adh,
            fig_hist_tto, tabla)


# ══════════════════════════════════════════════════════════════════
# 6. ENTRADA
# ══════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("\n" + "═"*55)
    print("  Dashboard — Control Metabólico DM2")
    print("  Zona de Salud 3 · MSP Ecuador")
    print("═"*55)
    print(f"  Dataset: {len(df_raw)} pacientes · {len(df_raw.columns)} variables")
    print("  Abre tu navegador en → http://127.0.0.1:8050")
    print("  Presiona Ctrl+C para detener")
    print("═"*55 + "\n")
    app.run(debug=False, port=8050)
